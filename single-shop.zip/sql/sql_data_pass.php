<?php
$db = new PDO('mysql:host=localhost;dbname=noz;charset=UTF8', 'root', 'mysql');

//$cats = $db->query("SELECT * FROM category")->fetchAll(PDO::FETCH_ASSOC);





